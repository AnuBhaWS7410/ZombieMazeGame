#pragma once
#include "Entity.h"
#include "Bullet.h"
using namespace std;
using namespace sf;

class Player : public Entity {
private:
    enum Direction{ Right = 0, Left = 1, Up = 2, Down = 3 };
    int currentFrame;
    Clock animationClock;
    float frameDelay;
    Direction lastDirection;
    int movesMade = 0;

public:
	Player();
	void update() override;
    void handleWindowCollision(const RenderWindow& window);
    void handleFurnitureCollision(const int furnitureLayout[10][10], const Sprite& tableSprite, const Sprite& cupboardSprite, const Sprite& boxSprite);
    Sprite& getSprite();
    int getMovesMade() const;
    vector<Bullet> bullets;

};