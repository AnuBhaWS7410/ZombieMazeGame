#include "Zombie.h"
#include<SFML\Window.hpp>

Zombie::Zombie() {
	textureRight.loadFromFile("Textures & Sprites/ZombieRight.png");
	zombieRight.setTexture(textureRight);
	zombieRight.setScale(0.1f, 0.1f);
	zombieRight.setTextureRect(IntRect(0, 0, 507, 1022));

	textureLeft.loadFromFile("Textures & Sprites/ZombieLeft.png");
	zombieLeft.setTexture(textureLeft);
	zombieLeft.setScale(0.15f, 0.15f);
	zombieLeft.setTextureRect(IntRect(0, 0, 458, 516));

	textureUp.loadFromFile("Textures & Sprites/ZombieUp.png");
	zombieUp.setTexture(textureUp);
	zombieUp.setScale(0.20f, 0.20f);
	zombieUp.setTextureRect(IntRect(0, 0, 341, 357));

	textureDown.loadFromFile("Textures & Sprites/ZombieDown.png");
	zombieDown.setTexture(textureDown);
	zombieDown.setScale(0.2f, 0.2f);
	zombieDown.setTextureRect(IntRect(0, 0, 347, 235));
}

void Zombie::update() {
    for (size_t i = 0; i < zombiesRight.size(); i++) {
        zombiesRight[i].move(5.f, 0.f);
    }

    for (size_t i = 0; i < zombiesLeft.size(); i++) {
        zombiesLeft[i].move(-5.f, 0.f);
    }

    for (size_t i = 0; i < zombiesUp.size(); i++) {
        zombiesUp[i].move(0.f, -5.f);
    }

    for (size_t i = 0; i < zombiesDown.size(); i++) {
        zombiesDown[i].move(0.f, 5.f);
    }

}
void Zombie::updateZombie(RenderWindow& window) {
    if (spawnTimerRight < 120) {
        spawnTimerRight++;
    }

    if (spawnTimerRight >= 120) {
        zombieRight.setPosition(-zombieRight.getGlobalBounds().width, rand() % window.getSize().y);
        zombiesRight.push_back((Sprite(zombieRight)));
        spawnTimerRight = 0;
    }

    if (spawnTimerLeft < 140) {
        spawnTimerLeft++;
    }

    if (spawnTimerLeft >= 140) {
        zombieLeft.setPosition(window.getSize().x + zombieLeft.getGlobalBounds().width, rand() % window.getSize().y);
        zombiesLeft.push_back((Sprite(zombieLeft)));
        spawnTimerLeft = 0;
    }

    if (spawnTimerUp < 170) {
        spawnTimerUp++;
    }

    if (spawnTimerUp >= 170) {
        zombieUp.setPosition(rand() % window.getSize().x, window.getSize().y + zombieUp.getGlobalBounds().height);
        zombiesUp.push_back((Sprite(zombieUp)));
        spawnTimerUp = 0;
    }

    if (spawnTimerDown < 90) {
        spawnTimerDown++;
    }

    if (spawnTimerDown >= 90) {
        zombieDown.setPosition(rand() % window.getSize().x, -zombieDown.getGlobalBounds().height);
        zombiesDown.push_back((Sprite(zombieDown)));
        spawnTimerDown = 0;
    }
}

void Zombie::render(RenderWindow& window) {
    for (size_t i = 0; i < zombiesLeft.size(); i++) {
        window.draw(zombiesLeft[i]);
    }
    for (size_t i = 0; i < zombiesRight.size(); i++) {
        window.draw(zombiesRight[i]);
    }
    for (size_t i = 0; i < zombiesUp.size(); i++) {
        window.draw(zombiesUp[i]);
    }
    for (size_t i = 0; i < zombiesDown.size(); i++) {
        window.draw(zombiesDown[i]);
    }
}

void Zombie::handleEnemyWindowCollision(RenderWindow& window) {
    for(size_t i = 0; i<zombiesDown.size(); i++){
        if (zombiesDown[i].getPosition().y > window.getSize().y) {
            zombiesDown.erase(zombiesDown.begin() + i);
        }
    }
    for (size_t i = 0; i < zombiesUp.size(); i++) {
        if (zombiesUp[i].getPosition().y + zombiesUp[i].getGlobalBounds().height < 0) {
            zombiesUp.erase(zombiesUp.begin() + i);
        }
    }
    for (size_t i = 0; i < zombiesLeft.size(); i++) {
        if (zombiesLeft[i].getPosition().x + zombiesLeft[i].getGlobalBounds().width < 0) {
            zombiesLeft.erase(zombiesLeft.begin() + i);
        }
    }
    for (size_t i = 0; i < zombiesRight.size(); i++) {
        if (zombiesRight[i].getPosition().x > window.getSize().x) {
            zombiesRight.erase(zombiesRight.begin() + i);
        }
    }
}

Sprite& Zombie::getEnemySprite() {
    return this->zombieDown;
    return this->zombieUp;
    return this->zombieRight;
    return this->zombieLeft;
}
