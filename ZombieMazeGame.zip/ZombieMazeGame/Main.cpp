#include<iostream>
#include<SFML\System.hpp>
#include<SFML\Window.hpp>
#include<SFML\Graphics.hpp>
#include<fstream>
#include<math.h>
#include<cmath>
#include "Player.h"
#include "Zombie.h"
#include "Bullet.h"
using namespace std;
using namespace sf;

enum GameState { MENU, LEVEL1, LEVEL2 };

bool loadFurnitureLayoutFromFile(const string& filename, int layout[10][10]) {
	ifstream file(filename);

	for (int row = 0; row < 10; ++row) {
		for (int col = 0; col < 10; ++col) {
			file >> layout[row][col];
		}
	}

	file.close();
	return true;
}

void runLevel1(RenderWindow& window){
	int furnitureLayout[10][10];
	loadFurnitureLayoutFromFile("maze.txt", furnitureLayout);

	Player player;
	int score = 0;
	int playerRow = 0;
	int playerCol = 0;

	Zombie zombie;

	srand(time(NULL));

	//Loading Background Image
	Texture bgTex;
	bgTex.loadFromFile("Textures & Sprites/Background.png");
	Sprite background(bgTex);

	//Loading Table Image
	Texture tbTex;
	tbTex.loadFromFile("Textures & Sprites/Table.png");
	Sprite table(tbTex);

	//Loading Cupboard Image
	Texture cupBTex;
	cupBTex.loadFromFile("Textures & Sprites/Cupboard.png");
	Sprite cupBoard(cupBTex);

	//Loading Box Image
	Texture boxTex;
	boxTex.loadFromFile("Textures & Sprites/Box.png");
	Sprite box(boxTex);

	//Loading Vaccine Image
	Texture vaccineTex;
	vaccineTex.loadFromFile("Textures & Sprites/Vaccine.png");
	Sprite vaccine(vaccineTex);

	vaccine.setScale(Vector2f(0.05f, 0.05f));
	vector<Sprite> vaccines;
	int vaccineSpawnTimer = 220;

	Font font;
	font.loadFromFile("Fonts/BungeeSpice-Regular.ttf");
	Text text;
	text.setFont(font);
	text.setPosition(Vector2f(0.f, 0.f));
	text.setString("Vaccines Collected: 0");
	text.setCharacterSize(15);
	int vaccinesCollected = 0;

	Text movesText;
	movesText.setFont(font);
	movesText.setCharacterSize(15);
	movesText.setFillColor(Color::White);
	movesText.setPosition(0.f, 30.f);

	Text healthText;
	healthText.setFont(font);
	healthText.setCharacterSize(15);
	healthText.setFillColor(Color::White);
	healthText.setString("Health: ");


	table.setScale(102.4 / tbTex.getSize().x, 102.4 / tbTex.getSize().y);
	cupBoard.setScale(102.4 / cupBTex.getSize().x, 102.4 / cupBTex.getSize().y);
	box.setScale(102.4 / boxTex.getSize().x, 102.4 / boxTex.getSize().y);

	int health = 10;
	RectangleShape healthBar;
	healthBar.setFillColor(Color::Green);
	healthBar.setSize(Vector2f((float)health * 20.f, 20.f));
	healthBar.setPosition(1024 - healthBar.getSize().x - 10.f, 1024 - 30.f);

	healthText.setPosition(1024 - healthBar.getGlobalBounds().width - 10.f, 1024 - healthBar.getGlobalBounds().height - healthText.getLocalBounds().height - 20.f);

	Text gameOver;
	gameOver.setCharacterSize(60);
	gameOver.setFont(font);
	gameOver.setString("Game Over");
	gameOver.setFillColor(Color::White);
	gameOver.setPosition(512 - gameOver.getGlobalBounds().width / 2, 100);

	Text Level1;
	Level1.setCharacterSize(60);
	Level1.setFont(font);
	Level1.setString("Level 1 Completed");
	Level1.setFillColor(Color::White);
	Level1.setPosition(512 - Level1.getGlobalBounds().width / 2, 100);

	bool isGameOver = false;
	bool isGameFinish = false;

	while (window.isOpen()) {
		Event event;
		while (window.pollEvent(event)) {
			if (event.type == Event::Closed) {
				window.close();
			}
			if (event.type == Event::KeyPressed && event.key.code == Keyboard::Escape) {
				window.close();
			}
		}
		//--------------------------//
		//---------UPDATE-----------//
		//--------------------------//
		if(!isGameOver && !isGameFinish){
			player.update();

			movesText.setString("Moves Made: " + to_string(player.getMovesMade()));

			player.handleFurnitureCollision(furnitureLayout, table, cupBoard, box);

			//Making vaccines appear on the screen
			if (vaccineSpawnTimer < 220) {
				vaccineSpawnTimer++;
			}
			if (vaccineSpawnTimer >= 220) {
				int row, col;
				do {
					row = rand() % 10;
					col = rand() % 10;
				} while (furnitureLayout[row][col] != 0);

				float x = col * 102.4f;
				float y = row * 102.4f;
				vaccine.setPosition(x, y);
				vaccines.push_back(Sprite(vaccine));
				vaccineSpawnTimer = 0;
			}

			// Collision detection between Player and Vaccines
			for (size_t i = 0; i < vaccines.size(); i++) {
				if (player.getSprite().getGlobalBounds().intersects(vaccines[i].getGlobalBounds())) {
					vaccines.erase(vaccines.begin() + i);
					vaccinesCollected++;
					text.setString("Vaccines Collected: " + to_string(vaccinesCollected));
				};
			}

			zombie.updateZombie(window);
			zombie.update();
			zombie.handleEnemyWindowCollision(window);

			//Collison detection between player and enemy
			for (size_t i = 0; i < zombie.zombiesLeft.size(); i++) {
				if (player.getSprite().getGlobalBounds().intersects(zombie.zombiesLeft[i].getGlobalBounds())) {
					zombie.zombiesLeft.erase(zombie.zombiesLeft.begin() + i);
					health--;
				};
			}

			for (size_t i = 0; i < zombie.zombiesRight.size(); i++) {
				if (player.getSprite().getGlobalBounds().intersects(zombie.zombiesRight[i].getGlobalBounds())) {
					zombie.zombiesRight.erase(zombie.zombiesRight.begin() + i);
					health--;
				};
			}

			for (size_t i = 0; i < zombie.zombiesUp.size(); i++) {
				if (player.getSprite().getGlobalBounds().intersects(zombie.zombiesUp[i].getGlobalBounds())) {
					zombie.zombiesUp.erase(zombie.zombiesUp.begin() + i);
					health--;
				};
			}

			for (size_t i = 0; i < zombie.zombiesDown.size(); i++) {
				if (player.getSprite().getGlobalBounds().intersects(zombie.zombiesDown[i].getGlobalBounds())) {
					zombie.zombiesDown.erase(zombie.zombiesDown.begin() + i);
					health--;
				};
			}

			//Health Bar Update
			healthBar.setSize(Vector2f((float)health * 20.f, 20.f));

			//Check Game Over
			if (health <= 0) {
				isGameOver = true;
			}

			if (vaccinesCollected >= 10 && health >= 0) {
				isGameFinish = true;
			}
		}

		//--------------------------//
		//-----------DRAW-----------//
		//--------------------------//
		window.clear();

		window.draw(background);

		for (size_t i = 0; i < vaccines.size(); i++) {
			window.draw(vaccines[i]);
		}

		player.render(window);
		player.handleWindowCollision(window);

		for (int row = 0; row < 10; row++) {
			for (int col = 0; col < 10; col++) {
				int item = furnitureLayout[row][col];
				float x = col * 102.4;
				float y = row * 102.4;


				if (item == 1) {
					table.setPosition(x, y);
					window.draw(table);
				}
				else if (item == 2) {
					cupBoard.setPosition(x, y);
					window.draw(cupBoard);
				}
				else if (item == 3) {
					box.setPosition(x, y);
					window.draw(box);
				}
			}
		}
		window.draw(movesText);

		window.draw(text);

		zombie.render(window);

		window.draw(healthText);

		window.draw(healthBar);

		if (isGameOver) {
			window.draw(gameOver);
		}
		if (isGameFinish) {
			window.draw(Level1);
		}
		window.display();
	}
}

void runLevel2(RenderWindow& window) {
	int furnitureLayout[10][10];
	loadFurnitureLayoutFromFile("maze.txt", furnitureLayout);

	Player player;
	int score = 0;
	int playerRow = 0;
	int playerCol = 0;

	Zombie zombie;

	srand(time(NULL));

	//Loading Background Image
	Texture bgTex;
	bgTex.loadFromFile("Textures & Sprites/Background.png");
	Sprite background(bgTex);

	//Loading Table Image
	Texture tbTex;
	tbTex.loadFromFile("Textures & Sprites/Table.png");
	Sprite table(tbTex);

	//Loading Cupboard Image
	Texture cupBTex;
	cupBTex.loadFromFile("Textures & Sprites/Cupboard.png");
	Sprite cupBoard(cupBTex);

	//Loading Box Image
	Texture boxTex;
	boxTex.loadFromFile("Textures & Sprites/Box.png");
	Sprite box(boxTex);

	//Loading Vaccine Image
	Texture vaccineTex;
	vaccineTex.loadFromFile("Textures & Sprites/Vaccine.png");
	Sprite vaccine(vaccineTex);

	vaccine.setScale(Vector2f(0.05f, 0.05f));
	vector<Sprite> vaccines;
	int vaccineSpawnTimer = 220;

	Font font;
	font.loadFromFile("Fonts/BungeeSpice-Regular.ttf");
	Text text;
	text.setFont(font);
	text.setPosition(Vector2f(0.f, 0.f));
	text.setString("Vaccines Collected: 0");
	text.setCharacterSize(15);
	int vaccinesCollected = 0;

	Text movesText;
	movesText.setFont(font);
	movesText.setCharacterSize(15);
	movesText.setFillColor(Color::White);
	movesText.setPosition(0.f, 30.f);

	Text healthText;
	healthText.setFont(font);
	healthText.setCharacterSize(15);
	healthText.setFillColor(Color::White);
	healthText.setString("Health: ");


	table.setScale(102.4 / tbTex.getSize().x, 102.4 / tbTex.getSize().y);
	cupBoard.setScale(102.4 / cupBTex.getSize().x, 102.4 / cupBTex.getSize().y);
	box.setScale(102.4 / boxTex.getSize().x, 102.4 / boxTex.getSize().y);

	int health = 10;
	RectangleShape healthBar;
	healthBar.setFillColor(Color::Green);
	healthBar.setSize(Vector2f((float)health * 20.f, 20.f));
	healthBar.setPosition(1024 - healthBar.getSize().x - 10.f, 1024 - 30.f);

	healthText.setPosition(1024 - healthBar.getGlobalBounds().width - 10.f, 1024 - healthBar.getGlobalBounds().height - healthText.getLocalBounds().height - 20.f);

	Text gameOver;
	gameOver.setCharacterSize(60);
	gameOver.setFont(font);
	gameOver.setString("Game Over");
	gameOver.setFillColor(Color::White);
	gameOver.setPosition(512 - gameOver.getGlobalBounds().width / 2, 100);

	Texture bulletTex;
	bulletTex.loadFromFile("Textures & Sprites/Bullet.png");

	Text Level1;
	Level1.setCharacterSize(60);
	Level1.setFont(font);
	Level1.setString("Level 2 Completed");
	Level1.setFillColor(Color::White);
	Level1.setPosition(512 - Level1.getGlobalBounds().width / 2, 100);

	int shootTimer = 20;

	Vector2f playerCenter;
	Vector2f mousePosWindow;
	Vector2f aimDir;
	Vector2f aimDirNorm;

	bool isGameOver = false;
	bool isGameFinish = false;

	while (window.isOpen()) {
		Event event;
		while (window.pollEvent(event)) {
			if (event.type == Event::Closed) {
				window.close();
			}
			if (event.type == Event::KeyPressed && event.key.code == Keyboard::Escape) {
				window.close();
			}
		}
		//--------------------------//
		//---------UPDATE-----------//
		//--------------------------//
		if (!isGameOver && !isGameFinish) {
			playerCenter = Vector2f(player.getSprite().getPosition().x + player.getSprite().getGlobalBounds().width / 2.f, player.getSprite().getPosition().y + player.getSprite().getGlobalBounds().height / 2.f);
			mousePosWindow = Vector2f(Mouse::getPosition(window));
			aimDir = mousePosWindow - playerCenter;
			aimDirNorm = aimDir / sqrt(aimDir.x * aimDir.x + aimDir.y * aimDir.y);

			Bullet b(&bulletTex, playerCenter);

			if (Mouse::isButtonPressed(Mouse::Left) && shootTimer >= 20) {
				b.currVelocity = aimDirNorm * b.maxSpeed;
				player.bullets.push_back(b);

			}

			for (size_t i = 0; i < player.bullets.size(); i++) {
				player.bullets[i].shape.move(player.bullets[i].currVelocity);
			}

			//Bullet out of window
			for(size_t i = 0; i<player.bullets.size(); i++){
				if (player.bullets[i].shape.getPosition().x > window.getSize().x) {
					player.bullets.erase(player.bullets.begin() + i);
				}
			}
			for (size_t i = 0; i < player.bullets.size(); i++) {
				if (player.bullets[i].shape.getPosition().x + player.bullets[i].shape.getGlobalBounds().width <  0) {
					player.bullets.erase(player.bullets.begin() + i);
				}
			}
			for (size_t i = 0; i < player.bullets.size(); i++) {
				if (player.bullets[i].shape.getPosition().y + player.bullets[i].shape.getGlobalBounds().height < 0) {
					player.bullets.erase(player.bullets.begin() + i);
				}
			}
			for (size_t i = 0; i < player.bullets.size(); i++) {
				if (player.bullets[i].shape.getPosition().y > window.getSize().y) {
					player.bullets.erase(player.bullets.begin() + i);
				}
			}

			//Collision detection bullets
			for (size_t i = 0; i < player.bullets.size(); i++) {
				for (size_t k = 0; k < zombie.zombiesLeft.size(); k++) {
					if (player.bullets[i].shape.getGlobalBounds().intersects(zombie.zombiesLeft[k].getGlobalBounds())) {
						zombie.zombiesLeft.erase(zombie.zombiesLeft.begin() + k);
						player.bullets.erase(player.bullets.begin() + i);
					}
				}
			}
			for (size_t i = 0; i < player.bullets.size(); i++) {
				for (size_t k = 0; k < zombie.zombiesRight.size(); k++) {
					if (player.bullets[i].shape.getGlobalBounds().intersects(zombie.zombiesRight[k].getGlobalBounds())) {
						zombie.zombiesRight.erase(zombie.zombiesRight.begin() + k);
						player.bullets.erase(player.bullets.begin() + i);
					}
				}
			}
			for (size_t i = 0; i < player.bullets.size(); i++) {
				for (size_t k = 0; k < zombie.zombiesUp.size(); k++) {
					if (player.bullets[i].shape.getGlobalBounds().intersects(zombie.zombiesUp[k].getGlobalBounds())) {
						zombie.zombiesUp.erase(zombie.zombiesUp.begin() + k);
						player.bullets.erase(player.bullets.begin() + i);
					}
				}
			}
			for (size_t i = 0; i < player.bullets.size(); i++) {
				for (size_t k = 0; k < zombie.zombiesDown.size(); k++) {
					if (player.bullets[i].shape.getGlobalBounds().intersects(zombie.zombiesDown[k].getGlobalBounds())) {
						zombie.zombiesDown.erase(zombie.zombiesDown.begin() + k);
						player.bullets.erase(player.bullets.begin() + i);
					}
				}
			}

			

			player.update();

			movesText.setString("Moves Made: " + to_string(player.getMovesMade()));

			player.handleFurnitureCollision(furnitureLayout, table, cupBoard, box);

			//Making vaccines appear on the screen
			if (vaccineSpawnTimer < 220) {
				vaccineSpawnTimer++;
			}
			if (vaccineSpawnTimer >= 220) {
				int row, col;
				do {
					row = rand() % 10;
					col = rand() % 10;
				} while (furnitureLayout[row][col] != 0);

				float x = col * 102.4f;
				float y = row * 102.4f;
				vaccine.setPosition(x, y);
				vaccines.push_back(Sprite(vaccine));
				vaccineSpawnTimer = 0;
			}

			// Collision detection between Player and Vaccines
			for (size_t i = 0; i < vaccines.size(); i++) {
				if (player.getSprite().getGlobalBounds().intersects(vaccines[i].getGlobalBounds())) {
					vaccines.erase(vaccines.begin() + i);
					vaccinesCollected++;
					text.setString("Vaccines Collected: " + to_string(vaccinesCollected));
				};
			}

			zombie.updateZombie(window);
			zombie.update();
			zombie.handleEnemyWindowCollision(window);

			//Collison detection between player and enemy
			for (size_t i = 0; i < zombie.zombiesLeft.size(); i++) {
				if (player.getSprite().getGlobalBounds().intersects(zombie.zombiesLeft[i].getGlobalBounds())) {
					zombie.zombiesLeft.erase(zombie.zombiesLeft.begin() + i);
					health--;
				};
			}

			for (size_t i = 0; i < zombie.zombiesRight.size(); i++) {
				if (player.getSprite().getGlobalBounds().intersects(zombie.zombiesRight[i].getGlobalBounds())) {
					zombie.zombiesRight.erase(zombie.zombiesRight.begin() + i);
					health--;
				};
			}

			for (size_t i = 0; i < zombie.zombiesUp.size(); i++) {
				if (player.getSprite().getGlobalBounds().intersects(zombie.zombiesUp[i].getGlobalBounds())) {
					zombie.zombiesUp.erase(zombie.zombiesUp.begin() + i);
					health--;
				};
			}

			for (size_t i = 0; i < zombie.zombiesDown.size(); i++) {
				if (player.getSprite().getGlobalBounds().intersects(zombie.zombiesDown[i].getGlobalBounds())) {
					zombie.zombiesDown.erase(zombie.zombiesDown.begin() + i);
					health--;
				};
			}

			//Health Bar Update
			healthBar.setSize(Vector2f((float)health * 20.f, 20.f));

			//Check Game Over
			if (health <= 0) {
				isGameOver = true;
			}

			if (vaccinesCollected >= 10 && health >= 0) {
				isGameFinish = true;
			}
		}

		//--------------------------//
		//-----------DRAW-----------//
		//--------------------------//
		window.clear();

		window.draw(background);

		for (size_t i = 0; i < vaccines.size(); i++) {
			window.draw(vaccines[i]);
		}

		for (size_t i = 0; i < player.bullets.size(); i++) {
			window.draw(player.bullets[i].shape);
		}

		player.render(window);
		player.handleWindowCollision(window);

		for (int row = 0; row < 10; row++) {
			for (int col = 0; col < 10; col++) {
				int item = furnitureLayout[row][col];
				float x = col * 102.4;
				float y = row * 102.4;


				if (item == 1) {
					table.setPosition(x, y);
					window.draw(table);
				}
				else if (item == 2) {
					cupBoard.setPosition(x, y);
					window.draw(cupBoard);
				}
				else if (item == 3) {
					box.setPosition(x, y);
					window.draw(box);
				}
			}
		}
		window.draw(movesText);

		window.draw(text);

		zombie.render(window);

		window.draw(healthText);

		window.draw(healthBar);

		if (health <= 0) {
			window.draw(gameOver);
		}

		if (isGameFinish) {
			window.draw(Level1);
		}

		window.display();
	}
}

int main() {
	RenderWindow window(VideoMode(1024, 1024), "ZombieMazeGame");
	window.setFramerateLimit(60);

	Font font;
	if (!font.loadFromFile("Fonts/BungeeSpice-Regular.ttf")) {
		return -1;
	}

	Text title;
	title.setCharacterSize(60);
	title.setFont(font);
	title.setString("Zombie Maze");
	title.setFillColor(Color::White);
	title.setPosition(512 - title.getGlobalBounds().width / 2, 100);

	RectangleShape level1Button(Vector2f(300.f, 80.f));
	level1Button.setFillColor(Color::Blue);
	level1Button.setPosition(362.f, 300.f);

	Text level1Text;
	level1Text.setCharacterSize(30);
	level1Text.setFont(font);
	level1Text.setString("Level 1");
	level1Text.setFillColor(Color::White);
	level1Text.setPosition(512 - level1Text.getGlobalBounds().width / 2, 315.f);

	RectangleShape level2Button(Vector2f(300.f, 80.f));
	level2Button.setFillColor(Color::Red);
	level2Button.setPosition(362.f, 420.f);

	Text level2Text;
	level2Text.setCharacterSize(30);
	level2Text.setFont(font);
	level2Text.setString("Level 2");
	level2Text.setFillColor(Color::White);
	level2Text.setPosition(512 - level2Text.getGlobalBounds().width / 2, 435.f);

	GameState currentState = MENU;
	while (window.isOpen()) {
		Event event;
		while (window.pollEvent(event)) {
			if (event.type == Event::Closed)
				window.close();
			if (event.type == Event::MouseButtonPressed && event.mouseButton.button == Mouse::Left) {
				Vector2f mousePos = window.mapPixelToCoords(Mouse::getPosition(window));
				if (currentState == MENU) {
					if (level1Button.getGlobalBounds().contains(mousePos)) {
						currentState = LEVEL1;
					}
					else if (level2Button.getGlobalBounds().contains(mousePos)) {
						currentState = LEVEL2;
					}
				}
			}
		}

		window.clear();

		if (currentState == MENU) {
			window.draw(title);
			window.draw(level1Button);
			window.draw(level1Text);
			window.draw(level2Button);
			window.draw(level2Text);
		}
		else if (currentState == LEVEL1) {
			runLevel1(window);
		}
		else if (currentState == LEVEL2) {
			runLevel2(window);
		}

		window.display();
	}
	return 0;
}
