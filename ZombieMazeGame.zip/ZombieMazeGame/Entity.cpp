#include "Entity.h"
#include<SFML\Graphics.hpp>
using namespace sf;

bool Entity::loadTexture(const string& filepath) {
    if (!texture.loadFromFile(filepath)) {
        return false;
    }
    sprite.setTexture(texture);
    return true;
}

void Entity::render(RenderWindow& window) {
    window.draw(sprite);
}
