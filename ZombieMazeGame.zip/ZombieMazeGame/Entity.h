#pragma once
#include<SFML/Graphics.hpp>
#include<string>
using namespace std;
using namespace sf;

class Entity {
protected:
    bool loadTexture(const string& filepath);

    Texture texture;
    Sprite sprite;
public:
    virtual void update() = 0;
    virtual void render(RenderWindow& window);
};
