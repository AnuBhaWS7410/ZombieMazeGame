#pragma once
#include <SFML/Graphics.hpp>
using namespace sf;

class Bullet {
public:
    Sprite shape;
    Vector2f currVelocity;
    float maxSpeed;

    Bullet(Texture* texture, Vector2f pos);
};