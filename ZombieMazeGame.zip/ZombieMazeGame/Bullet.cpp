#include "Bullet.h"
#include "Player.h"

Bullet::Bullet(Texture* texture, Vector2f pos) : currVelocity(0.f, 0.f), maxSpeed(15.f){
    this->shape.setTexture(*texture);
    this->shape.setScale(0.002f, 0.006f);
    this->shape.setPosition(pos);
}
