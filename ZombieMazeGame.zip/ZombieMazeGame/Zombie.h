#pragma once
#include "Entity.h"
#include<SFML/Graphics.hpp>
using namespace sf;

class Zombie : public Entity {
public:
    Texture textureRight;
    Texture textureLeft;
    Texture textureUp;
    Texture textureDown;

    Sprite zombieRight;
    Sprite zombieLeft;
    Sprite zombieUp;
    Sprite zombieDown;

    vector<Sprite> zombiesRight;
    vector<Sprite> zombiesLeft;
    vector<Sprite> zombiesUp;
    vector<Sprite> zombiesDown;

    int spawnTimerRight = 0;
    int spawnTimerLeft = 0;
    int spawnTimerUp = 0;
    int spawnTimerDown = 0;

    Zombie();
    void updateZombie(RenderWindow& window);
    void update() override;
    void render(RenderWindow& window);
    void handleEnemyWindowCollision(RenderWindow& window);
    Sprite& getEnemySprite();
};