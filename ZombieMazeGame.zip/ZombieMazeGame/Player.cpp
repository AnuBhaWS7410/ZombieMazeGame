#include "Player.h"
#include<SFML\Window.hpp>

Player::Player() : currentFrame(0), frameDelay(0.1f), lastDirection(Right) {
	loadTexture("Textures & Sprites/MainPlayer.png");
	sprite.setPosition(0.f, 30.f);
	sprite.setTextureRect(IntRect(0,0,445,570));
	sprite.setScale(Vector2f(0.11f, 0.11f));
}

void Player::update() {
    bool isMoving = false;

    if (Keyboard::isKeyPressed(Keyboard::A)) {
        sprite.move(-3.f, 0.f);
        isMoving = true;
        lastDirection = Left;

        if (animationClock.getElapsedTime().asSeconds() >= frameDelay) {
            currentFrame = (currentFrame + 1) % 3;
            sprite.setTextureRect(IntRect(currentFrame * 445, 1 * 570, 445, 570));
            animationClock.restart();
        }
        movesMade++;
    }
    else if (Keyboard::isKeyPressed(Keyboard::D)) {
        sprite.move(3.f, 0.f);
        isMoving = true;
        lastDirection = Right;

        if (animationClock.getElapsedTime().asSeconds() >= frameDelay) {
            currentFrame = (currentFrame + 1) % 3;
            sprite.setTextureRect(IntRect(currentFrame * 445, 0 * 570, 445, 570));
            animationClock.restart();
        }
        movesMade++;
    }
    else if (Keyboard::isKeyPressed(Keyboard::W)) {
        sprite.move(0.f, -3.f);
        isMoving = true;
        lastDirection = Up;

        if (animationClock.getElapsedTime().asSeconds() >= frameDelay) {
            currentFrame = (currentFrame + 1) % 3;
            sprite.setTextureRect(IntRect(currentFrame * 477, 2 * 615, 477, 615));
            animationClock.restart();
        }
        movesMade++;
    }
    else if (Keyboard::isKeyPressed(Keyboard::S)) {
        sprite.move(0.f, 3.f);
        isMoving = true;
        lastDirection = Down;

        if (animationClock.getElapsedTime().asSeconds() >= frameDelay) {
            currentFrame = (currentFrame + 1) % 2;
            sprite.setTextureRect(IntRect(currentFrame * 477, 3 * 640, 477, 640));
            animationClock.restart();
        }
        movesMade++;
    }

    if (!isMoving) {
        currentFrame = 0;
        switch (lastDirection) {
        case Left:
            sprite.setTextureRect(IntRect(0, 1 * 570, 445, 570));
            break;
        case Right:
            sprite.setTextureRect(IntRect(0, 0 * 570, 445, 570));
            break;
        case Up:
            sprite.setTextureRect(IntRect(0, 2 * 615, 477, 615));
            break;
        case Down:
            sprite.setTextureRect(IntRect(0, 3 * 640, 477, 640));
            break;
        }
    }
}

void Player::handleWindowCollision(const RenderWindow& window) {
    Vector2f pos = sprite.getPosition();
    FloatRect bounds = sprite.getGlobalBounds();

    if (pos.x < 0){
        sprite.setPosition(0.f, pos.y);
    }
    if (pos.x + bounds.width > window.getSize().x){
        sprite.setPosition(window.getSize().x - bounds.width, pos.y);
    }
    if (pos.y < 0){ 
        sprite.setPosition(pos.x, 0.f); 
    }
    if (pos.y + bounds.height > window.getSize().y){
        sprite.setPosition(pos.x, window.getSize().y - bounds.height);
    }
}

void Player::handleFurnitureCollision(const int furnitureLayout[10][10], const Sprite& tableSprite, const Sprite& cupboardSprite, const Sprite& boxSprite
) {
    Font font;
    if (!font.loadFromFile("Fonts/BungeeSpice-Regular.ttf"));
    Text text;
    text.setFont(font);
    text.setPosition(Vector2f(10.f, 10.f));
    text.setString("Moves Made: ");
    text.setCharacterSize(15);

    FloatRect playerBounds = sprite.getGlobalBounds();

    for (int row = 0; row < 10; ++row) {
        for (int col = 0; col < 10; ++col) {
            int item = furnitureLayout[row][col];
            if (item == 0) {
                continue;
            }

            Sprite furniture;
            if (item == 1){
                furniture = tableSprite;
            }
            else if (item == 2){
                furniture = cupboardSprite;
            }
            else if (item == 3){
                furniture = cupboardSprite;
            }

            furniture.setPosition(col * 102.f, row * 102.f);

            if (playerBounds.intersects(furniture.getGlobalBounds())) {
                if (Keyboard::isKeyPressed(Keyboard::W)) {
                    sprite.move(0.f, 5.f); 
                }
                else if (Keyboard::isKeyPressed(Keyboard::S)) {
                    sprite.move(0.f, -5.f); 
                }
                else if (Keyboard::isKeyPressed(Keyboard::A)) {
                    sprite.move(5.f, 0.f);  
                }
                else if (Keyboard::isKeyPressed(Keyboard::D)) {
                    sprite.move(-5.f, 0.f); 
                }
                return; 
            }
        }
    }
}

Sprite& Player::getSprite() {
    return this->sprite;
}

int Player::getMovesMade() const {
    return movesMade;
}





